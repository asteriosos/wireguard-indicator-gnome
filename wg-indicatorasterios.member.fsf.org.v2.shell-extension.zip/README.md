## WG Indicator Extension

![alt tag](demo.png)

This is a simple extension that is basically polls for a wg0 device from ip on a three second timer.

It is a fork of the vpn-indicator-gnome-extension.

https://extensions.gnome.org/extension/1134/vpn-indicator/

Just install it via the gnome tweak utility.

---
