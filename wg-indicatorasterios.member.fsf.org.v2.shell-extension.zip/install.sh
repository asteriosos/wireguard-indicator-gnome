#!/bin/bash

dir=~/.local/share/gnome-shell/extensions/wg-indicator@asterios.member.fsf.org

rm -rf $dir
cp -R . $dir
